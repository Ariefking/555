
# CARA INSTALL
Mohon gunakan sc ini dngn bijak
------
- `git clone https://github.com/dhenza1415/SILENTJS2`
- `cd SILENTJS2 && npm install`
- `cd src`
- `npm start`


## FOLLOW
------
[@Dhenza](https://instagram.com/dhenza15)
